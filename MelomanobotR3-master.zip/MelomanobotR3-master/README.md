# MelomanobotR3

![](http://www.fd4a.net/Android_Icons/3D-Matrix-Pro-Vol-3-Revolution.png)

Nombre del Equipo: Melomanobot / Proyecto: R3

### Resumen

Melomanobot es un Robot melómano que viene de un futuro en el que se ha prohibido la música y que viaja en el tiempo para conseguir ayuda conversando con la gente y así poder llevar información sobre la historia de la música y los diferentes géneros a su tiempo presente


### Contexto 

Un mundo futuro en el que la música es considerada un estímulo destructivo para el cerebro y es prohibida

### Personaje

Melomanobot es un Bot que está en desacuerdo con la decisión de prohibir la música. Su curiosidad y su afán de conocimiento musical le harán embarcarse en una aventura en la que deberá usar sus dotes conversacionales y su enorme capacidad para explicar la historia musical para captar la ayuda de todom aquel que decida conversar con él

### Historia

El Dr. Miller (investigador del departamento de Psicolgía de la Universidad de Harvard) publicó un estudio que definía a la música como un estímulod estructivo para el cerebro humano. Dos años después el Gobierno de los EEUU decide iniciar la Depuración Polifónica: Primero se borraron todas las apps y webs de reproducción musical. Después se clausruaron tiendas musicales y se confiscaron instrumentos. el tercer día todo ciudadano debía entregar cualquier pertenencia relacionada con el mundo de la música. El cuarto día le tocó el turno a los aparatos capaces de almacenar sonidos, que fueron modificados para ser incapaces de realizar dicha función. El quinto y último día se promulgó una ley que prohibía la creación, distribución y venta de música. Poco a poco todos los países se sumaron a la depuración hasta que la música desapareció de la tierra.

### Conflicto

Tras la depuración mundial, Melomanobot decide arriesgarse y emprender un viaje en el tiempo en búsqueda de conocimiento musical y ayuda de gente de todas las épocas para poder desmentir los estudios del Dr. Miller y del Gobiernod e los EEUU.




- ChatBot:  https://t.me/Melomano1Bot

- Banner:  

- Storytelling: 

------
![](https://upload.wikimedia.org/wikipedia/commons/thumb/6/62/CC-BY-SA-Andere_Wikis_%28v%29.svg/200px-CC-BY-SA-Andere_Wikis_%28v%29.svg.png)


Autores: 
- :man: Felipe de la Peña
- :woman: Jessi Hurling


<!---
Lista completa de emojis de markDown - https://gist.github.com/rxaviers/7360908) 
-->



Marzo, 2019

[Creacion y Difusión de Nuevos Contenidos Audiovisuales](http://utopolis.ugr.es/medialab)

[Facultad de Comunicación y Documentación](http://fcd.ugr.es)

Universidad de Granada
